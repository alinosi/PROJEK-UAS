import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MataKuliahFrame extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtNama; // Dideklarasikan sebagai field
    private JTextField txtID;   // Dideklarasikan sebagai field

    public MataKuliahFrame() {
        setTitle("Kelola Data Mata Kuliah");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Inisialisasi tabel dan model
        tableModel = new DefaultTableModel(new String[]{"ID", "Nama"}, 0);
        table = new JTable(tableModel);
        loadMataKuliahData();
        JScrollPane scrollPane = new JScrollPane(table);

        // Inisialisasi form input
        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        txtNama = new JTextField(); // Inisialisasi field txtNama
        txtID = new JTextField();   // Inisialisasi field txtID
        txtID.setEditable(false);
        formPanel.add(new JLabel("Nama Mata Kuliah:"));
        formPanel.add(txtNama);
        formPanel.add(new JLabel("ID (Untuk Edit/Delete):"));
        formPanel.add(txtID);

        // Inisialisasi tombol CRUD
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        JButton btnTambah = new JButton("Tambah");
        JButton btnEdit = new JButton("Edit");
        JButton btnHapus = new JButton("Hapus");
        JButton btnRefresh = new JButton("Refresh");
        buttonPanel.add(btnTambah);
        buttonPanel.add(btnEdit);
        buttonPanel.add(btnHapus);
        buttonPanel.add(btnRefresh);

        // Tambahkan komponen ke panel utama
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Tambahkan panel ke frame
        add(panel);

        // Tambahkan event listener untuk tombol
        btnTambah.addActionListener((ActionEvent e) -> {
            try {
                String nama = txtNama.getText();
                new MataKuliah().createMataKuliah(nama);
                JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
                loadMataKuliahData();
                txtNama.setText("");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnEdit.addActionListener((ActionEvent e) -> {
            try {
                int id = Integer.parseInt(txtID.getText());
                String nama = txtNama.getText();
                new MataKuliah().updateMataKuliah(id, nama);
                JOptionPane.showMessageDialog(this, "Data berhasil diperbarui!");
                loadMataKuliahData();
                txtNama.setText("");
                txtID.setText("");
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnHapus.addActionListener((ActionEvent e) -> {
            try {
                int id = Integer.parseInt(txtID.getText());
                new MataKuliah().deleteMataKuliah(id);
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                loadMataKuliahData();
                txtID.setText("");
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnRefresh.addActionListener((ActionEvent e) -> loadMataKuliahData());

        // Tambahkan event listener ke tabel
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int selectedRow = table.getSelectedRow(); // Ambil baris yang diklik
                if (selectedRow >= 0) {
                    txtID.setText(tableModel.getValueAt(selectedRow, 0).toString());
                    txtNama.setText(tableModel.getValueAt(selectedRow, 1).toString());
                }
            }
        });
    }

    private void loadMataKuliahData() {
        try {
            tableModel.setRowCount(0); // Reset tabel
            ResultSet rs = new MataKuliah().readMataKuliah();
            while (rs.next()) {
                tableModel.addRow(new Object[]{rs.getInt("idmk"), rs.getString("nama")});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
