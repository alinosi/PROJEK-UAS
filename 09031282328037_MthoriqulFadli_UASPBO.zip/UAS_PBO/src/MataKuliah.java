import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MataKuliah {
    public void createMataKuliah(String nama) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "INSERT INTO MataKuliah (nama) VALUES (?)";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, nama);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public ResultSet readMataKuliah() throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "SELECT * FROM MataKuliah";
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(query);
    }

    public void updateMataKuliah(int id, String nama) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "UPDATE MataKuliah SET nama = ? WHERE idmk = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, nama);
        stmt.setInt(2, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public void deleteMataKuliah(int id) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "DELETE FROM MataKuliah WHERE idmk = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }
}
