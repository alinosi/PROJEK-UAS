import java.sql.*;

public class Mahasiswa {
    public void createMahasiswa(String nama, String nim) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "INSERT INTO Mahasiswa (nama, nim) VALUES (?, ?)";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, nama);
        stmt.setString(2, nim);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public ResultSet readMahasiswa() throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "SELECT * FROM Mahasiswa";
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(query);
    }

    public void updateMahasiswa(int id, String nama, String nim) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "UPDATE Mahasiswa SET nama = ?, nim = ? WHERE idmhs = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, nama);
        stmt.setString(2, nim);
        stmt.setInt(3, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public void deleteMahasiswa(int id) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "DELETE FROM Mahasiswa WHERE idmhs = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }
}
