import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("CRUD Sistem Akademik");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));

        JButton btnMahasiswa = new JButton("Kelola Mahasiswa");
        JButton btnMataKuliah = new JButton("Kelola Mata Kuliah");
        JButton btnKRS = new JButton("Kelola KRS");
        JButton btnExit = new JButton("Keluar");

        panel.add(btnMahasiswa);
        panel.add(btnMataKuliah);
        panel.add(btnKRS);
        panel.add(btnExit);

        add(panel);

        // Action listeners
        btnMahasiswa.addActionListener(e -> new MahasiswaFrame().setVisible(true));
        btnMataKuliah.addActionListener(e -> new MataKuliahFrame().setVisible(true));
        btnKRS.addActionListener(e -> new KRSFrame().setVisible(true));
        btnExit.addActionListener(e -> System.exit(0));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
