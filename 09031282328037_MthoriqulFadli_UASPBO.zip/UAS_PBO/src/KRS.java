import java.sql.*;

public class KRS {
    public void createKRS(int idmhs, int idmk, String semester, String tahunajaran) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "INSERT INTO KRS (idmhs, idmk, semester, tahunajaran) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, idmhs);
        stmt.setInt(2, idmk);
        stmt.setString(3, semester);
        stmt.setString(4, tahunajaran);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public ResultSet readKRS() throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "SELECT * FROM KRS";
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(query);
    }

    public void updateKRS(int id, int idmhs, int idmk, String semester, String tahunajaran) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "UPDATE KRS SET idmhs = ?, idmk = ?, semester = ?, tahunajaran = ? WHERE idkrs = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, idmhs);
        stmt.setInt(2, idmk);
        stmt.setString(3, semester);
        stmt.setString(4, tahunajaran);
        stmt.setInt(5, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public void deleteKRS(int id) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "DELETE FROM KRS WHERE idkrs = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }
}
