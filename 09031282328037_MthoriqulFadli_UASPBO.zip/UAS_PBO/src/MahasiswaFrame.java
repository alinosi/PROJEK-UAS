import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MahasiswaFrame extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtNama; // Dideklarasikan sebagai field
    private JTextField txtNIM;  // Dideklarasikan sebagai field
    private JTextField txtID;   // Dideklarasikan sebagai field

    public MahasiswaFrame() {
        setTitle("Kelola Data Mahasiswa");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel panel = new JPanel(new BorderLayout());

        // Inisialisasi tabel dan model
        tableModel = new DefaultTableModel(new String[]{"ID", "Nama", "NIM"}, 0);
        table = new JTable(tableModel);
        loadMahasiswaData(); // Load data mahasiswa ke tabel
        JScrollPane scrollPane = new JScrollPane(table);

        // Inisialisasi form input
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        txtNama = new JTextField(); // Inisialisasi field txtNama
        txtNIM = new JTextField();  // Inisialisasi field txtNIM
        txtID = new JTextField();   // Inisialisasi field txtID
        txtID.setEditable(false);
        formPanel.add(new JLabel("Nama:"));
        formPanel.add(txtNama);
        formPanel.add(new JLabel("NIM:"));
        formPanel.add(txtNIM);
        formPanel.add(new JLabel("ID (Untuk Edit/Delete):"));
        formPanel.add(txtID);

        // Inisialisasi tombol CRUD
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        JButton btnTambah = new JButton("Tambah");
        JButton btnEdit = new JButton("Edit");
        JButton btnHapus = new JButton("Hapus");
        JButton btnRefresh = new JButton("Refresh");
        buttonPanel.add(btnTambah);
        buttonPanel.add(btnEdit);
        buttonPanel.add(btnHapus);
        buttonPanel.add(btnRefresh);

        // Tambahkan komponen ke panel utama
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Tambahkan panel ke frame
        add(panel);

        // Tambahkan event listener untuk tombol
        btnTambah.addActionListener((ActionEvent e) -> {
            try {
                String nama = txtNama.getText();
                String nim = txtNIM.getText();
                new Mahasiswa().createMahasiswa(nama, nim);
                JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
                loadMahasiswaData();
                txtNama.setText("");
                txtNIM.setText("");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnEdit.addActionListener((ActionEvent e) -> {
            try {
                int id = Integer.parseInt(txtID.getText());
                String nama = txtNama.getText();
                String nim = txtNIM.getText();
                new Mahasiswa().updateMahasiswa(id, nama, nim);
                JOptionPane.showMessageDialog(this, "Data berhasil diperbarui!");
                loadMahasiswaData();
                txtNama.setText("");
                txtNIM.setText("");
                txtID.setText("");
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnHapus.addActionListener((ActionEvent e) -> {
            try {
                int id = Integer.parseInt(txtID.getText());
                new Mahasiswa().deleteMahasiswa(id);
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                loadMahasiswaData();
                txtID.setText("");
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnRefresh.addActionListener((ActionEvent e) -> loadMahasiswaData());

        // Tambahkan event listener ke tabel
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int selectedRow = table.getSelectedRow(); // Ambil baris yang diklik
                if (selectedRow >= 0) {
                    txtID.setText(tableModel.getValueAt(selectedRow, 0).toString());
                    txtNama.setText(tableModel.getValueAt(selectedRow, 1).toString());
                    txtNIM.setText(tableModel.getValueAt(selectedRow, 2).toString());
                }
            }
        });
    }

    private void loadMahasiswaData() {
        try {
            tableModel.setRowCount(0); // Reset tabel
            ResultSet rs = new Mahasiswa().readMahasiswa();
            while (rs.next()) {
                tableModel.addRow(new Object[]{rs.getInt("idmhs"), rs.getString("nama"), rs.getString("nim")});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
