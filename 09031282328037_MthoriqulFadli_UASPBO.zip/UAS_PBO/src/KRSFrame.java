import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

public class KRSFrame extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;

    public KRSFrame() {
        setTitle("Kelola Data KRS");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Tabel
        tableModel = new DefaultTableModel(new String[]{"ID KRS", "ID Mahasiswa", "ID Mata Kuliah", "Semester", "Tahun Ajaran"}, 0);
        table = new JTable(tableModel);
        loadKRSData();
        JScrollPane scrollPane = new JScrollPane(table);

        // Form Input
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField txtIDKRS = new JTextField();
        JTextField txtIDMhs = new JTextField();
        JTextField txtIDMK = new JTextField();
        JTextField txtSemester = new JTextField();
        JTextField txtTahunAjaran = new JTextField();

        txtIDKRS.setEditable(false); // ID otomatis diisi dari tabel
        formPanel.add(new JLabel("ID KRS (Untuk Edit/Delete):"));
        formPanel.add(txtIDKRS);
        formPanel.add(new JLabel("ID Mahasiswa:"));
        formPanel.add(txtIDMhs);
        formPanel.add(new JLabel("ID Mata Kuliah:"));
        formPanel.add(txtIDMK);
        formPanel.add(new JLabel("Semester:"));
        formPanel.add(txtSemester);
        formPanel.add(new JLabel("Tahun Ajaran:"));
        formPanel.add(txtTahunAjaran);

        // Tombol CRUD
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        JButton btnTambah = new JButton("Tambah");
        JButton btnEdit = new JButton("Edit");
        JButton btnHapus = new JButton("Hapus");
        JButton btnRefresh = new JButton("Refresh");
        buttonPanel.add(btnTambah);
        buttonPanel.add(btnEdit);
        buttonPanel.add(btnHapus);
        buttonPanel.add(btnRefresh);

        // Tambahkan komponen ke panel utama
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Tambahkan panel ke frame
        add(panel);

        // Event listeners
        btnTambah.addActionListener((ActionEvent e) -> {
            try {
                int idMhs = Integer.parseInt(txtIDMhs.getText());
                int idMK = Integer.parseInt(txtIDMK.getText());
                String semester = txtSemester.getText();
                String tahunAjaran = txtTahunAjaran.getText();

                new KRS().createKRS(idMhs, idMK, semester, tahunAjaran);
                JOptionPane.showMessageDialog(this, "Data KRS berhasil ditambahkan!");
                loadKRSData();
                clearForm(txtIDMhs, txtIDMK, txtSemester, txtTahunAjaran);
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnEdit.addActionListener((ActionEvent e) -> {
            try {
                int idKRS = Integer.parseInt(txtIDKRS.getText());
                int idMhs = Integer.parseInt(txtIDMhs.getText());
                int idMK = Integer.parseInt(txtIDMK.getText());
                String semester = txtSemester.getText();
                String tahunAjaran = txtTahunAjaran.getText();

                new KRS().updateKRS(idKRS, idMhs, idMK, semester, tahunAjaran);
                JOptionPane.showMessageDialog(this, "Data KRS berhasil diperbarui!");
                loadKRSData();
                clearForm(txtIDKRS, txtIDMhs, txtIDMK, txtSemester, txtTahunAjaran);
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnHapus.addActionListener((ActionEvent e) -> {
            try {
                int idKRS = Integer.parseInt(txtIDKRS.getText());
                new KRS().deleteKRS(idKRS);
                JOptionPane.showMessageDialog(this, "Data KRS berhasil dihapus!");
                loadKRSData();
                clearForm(txtIDKRS, txtIDMhs, txtIDMK, txtSemester, txtTahunAjaran);
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnRefresh.addActionListener((ActionEvent e) -> loadKRSData());

        // Event listener untuk tabel (klik baris)
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    // Ambil data dari baris yang dipilih dan masukkan ke form
                    txtIDKRS.setText(tableModel.getValueAt(selectedRow, 0).toString());
                    txtIDMhs.setText(tableModel.getValueAt(selectedRow, 1).toString());
                    txtIDMK.setText(tableModel.getValueAt(selectedRow, 2).toString());
                    txtSemester.setText(tableModel.getValueAt(selectedRow, 3).toString());
                    txtTahunAjaran.setText(tableModel.getValueAt(selectedRow, 4).toString());
                }
            }
        });
    }

    private void loadKRSData() {
        try {
            tableModel.setRowCount(0);
            ResultSet rs = new KRS().readKRS();
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("idkrs"),
                    rs.getInt("idmhs"),
                    rs.getInt("idmk"),
                    rs.getString("semester"),
                    rs.getString("tahunajaran")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void clearForm(JTextField... fields) {
        for (JTextField field : fields) {
            field.setText("");
        }
    }
}
